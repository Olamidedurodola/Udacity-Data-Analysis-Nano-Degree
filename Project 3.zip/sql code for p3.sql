SELECT count(Name) 
FROM Track 
WHERE Composer = 'U2';
--------------------------------------------------------------------------------
SELECT max(Total) 
FROM Invoice 
WHERE BillingCountry = 'Spain';
--------------------------------------------------------------------------------
SELECT Title 
FROM Employee 
WHERE LastName = 'Johnson';
--------------------------------------------------------------------------------
select * from Invoice;
--------------------------------------------------------------------------------
SELECT BillingCountry, COUNT(*) AS Invoices
FROM Invoice
GROUP BY BillingCountry
ORDER BY Invoices DESC;
--------------------------------------------------------------------------------
SELECT BillingCity, SUM(Total) AS TotalSales
FROM Invoice
GROUP BY BillingCity
ORDER BY TotalSales DESC
LIMIT 1;
--------------------------------------------------------------------------------
SELECT Customer.FirstName, Customer.LastName, SUM(InvoiceLine.Quantity * InvoiceLine.UnitPrice) AS TotalSpent
FROM Invoice
INNER JOIN InvoiceLine ON Invoice.InvoiceId = InvoiceLine.InvoiceId
INNER JOIN Customer ON Invoice.CustomerId = Customer.CustomerId
GROUP BY Customer.CustomerId
ORDER BY TotalSpent DESC
LIMIT 1;
--------------------------------------------------------------------------------

SELECT Customer.Email, Customer.FirstName, Customer.LastName, Genre.Name AS Genre
FROM Customer
INNER JOIN Invoice ON Customer.CustomerId = Invoice.CustomerId
INNER JOIN InvoiceLine ON Invoice.InvoiceId = InvoiceLine.InvoiceId
INNER JOIN Track ON InvoiceLine.TrackId = Track.TrackId
INNER JOIN Genre ON Track.GenreId = Genre.GenreId
WHERE Genre.Name = 'Rock'
ORDER BY Customer.Email ASC;

--------------------------------------------------------------------------------

SELECT Artist.Name AS Artist, COUNT(Track.TrackId) AS TrackCount
FROM Genre
INNER JOIN Track ON Genre.GenreId = Track.GenreId
INNER JOIN Album ON Track.AlbumId = Album.AlbumId
INNER JOIN Artist ON Album.ArtistId = Artist.ArtistId
WHERE Genre.Name = 'Rock'
GROUP BY Artist.ArtistId
ORDER BY TrackCount DESC
LIMIT 10;

--------------------------------------------------------------------------------

SELECT Artist.Name AS Artist, Customer.FirstName, Customer.LastName, SUM(InvoiceLine.Quantity * InvoiceLine.UnitPrice) AS TotalSpent
FROM Invoice
INNER JOIN InvoiceLine ON Invoice.InvoiceId = InvoiceLine.InvoiceId
INNER JOIN Track ON InvoiceLine.TrackId = Track.TrackId
INNER JOIN Album ON Track.AlbumId = Album.AlbumId
INNER JOIN Artist ON Album.ArtistId = Artist.ArtistId
INNER JOIN Customer ON Invoice.CustomerId = Customer.CustomerId
GROUP BY Artist.ArtistId, Customer.CustomerId
ORDER BY TotalSpent DESC
LIMIT 5;

--------------------------------------------------------------------------------
SELECT Customer.Country, Genre.Name AS Genre, SUM(InvoiceLine.Quantity) AS Purchases
FROM Invoice
INNER JOIN InvoiceLine ON Invoice.InvoiceId = InvoiceLine.InvoiceId
INNER JOIN Customer ON Invoice.CustomerId = Customer.CustomerId
INNER JOIN Track ON InvoiceLine.TrackId = Track.TrackId
INNER JOIN Genre ON Track.GenreId = Genre.GenreId
GROUP BY Customer.Country, Genre.GenreId
HAVING Purchases = (SELECT MAX(Purchases) FROM (
    SELECT Customer.Country, Genre.Name AS Genre, SUM(InvoiceLine.Quantity) AS Purchases
    FROM Invoice
    INNER JOIN InvoiceLine ON Invoice.InvoiceId = InvoiceLine.InvoiceId
    INNER JOIN Customer ON Invoice.CustomerId = Customer.CustomerId
    INNER JOIN Track ON InvoiceLine.TrackId = Track.TrackId
    INNER JOIN Genre ON Track.GenreId = Genre.GenreId
    GROUP BY Customer.Country, Genre.GenreId
) AS MaxPurchases WHERE MaxPurchases.Country = Customer.Country);


--------------------------------------------------------------------------------
SELECT Name, Milliseconds
FROM Track
WHERE Milliseconds > (SELECT AVG(Milliseconds) FROM Track)
ORDER BY Milliseconds DESC;

--------------------------------------------------------------------------------
SELECT Customer.Country, Customer.FirstName, Customer.LastName, SUM(Invoice.Total) AS TotalSpent
FROM Customer
INNER JOIN Invoice ON Customer.CustomerId = Invoice.CustomerId
GROUP BY Customer.Country, Customer.CustomerId
HAVING TotalSpent = (SELECT MAX(TotalSpent) FROM (
    SELECT Customer.Country, SUM(Invoice.Total) AS TotalSpent
    FROM Customer
    INNER JOIN Invoice ON Customer.CustomerId = Invoice.CustomerId
    GROUP BY Customer.Country
) AS MaxSpent WHERE MaxSpent.Country = Customer.Country);

---------------------------------------------------------------------------------


---PROJECT QUERY-------------
/*This query counts the number of unique albums in the 
Track table by joining the Track table to the Album table 
and using the COUNT aggregation function with the DISTINCT keyword. */

SELECT COUNT(DISTINCT AlbumId)
FROM Track
JOIN Album ON Track.AlbumId = Album.AlbumId

/*
This query calculates the average unit price of tracks 
in the Track table with a genre of 'Rock' by joining the 
Track table to the Genre table, using the AVG aggregation function, 
and filtering the results with a WHERE clause.  */

SELECT AVG(UnitPrice)
FROM Track
JOIN Genre ON Track.GenreId = Genre.GenreId
WHERE Genre.Name = 'Rock'


/*
This query calculates the total sales for each customer in the Invoice table 
by joining the InvoiceLine table to the Invoice table, using the SUM aggregation 
function to multiply the Quantity and UnitPrice columns, and grouping the results 
by CustomerId.

 */

SELECT SUM(Quantity * UnitPrice) AS TotalSales
FROM InvoiceLine
JOIN Invoice ON InvoiceLine.InvoiceId = Invoice.InvoiceId
GROUP BY Invoice.CustomerId


/*
This query counts the number of tracks for each artist in the Track table who have 
more than 10 tracks, by joining the Track table to the Album and Artist tables, 
using the COUNT aggregation function, grouping the results by ArtistId, and using 
the HAVING clause to filter the results

 */
 SELECT COUNT(*) AS NumTracks, Artist.Name
FROM Track
JOIN Album ON Track.AlbumId = Album.AlbumId
JOIN Artist ON Album.ArtistId = Artist.ArtistId
GROUP BY Artist.ArtistId
HAVING COUNT(*) > 10
ORDER BY NumTracks
lIMIT 20;

  
 /*
What are the names of the top 5 customers who have spent the most money on invoices?
 */
 
SELECT c.FirstName, c.LastName, SUM(i.Total) as 'Total Spent'
FROM Customer c
JOIN Invoice i ON c.CustomerId = i.CustomerId
GROUP BY c.FirstName, c.LastName
ORDER BY SUM(i.Total) DESC
LIMIT 10;
 
 /*
What are the names of the top 5 genres with the most tracks?
 */
 SELECT g.Name, COUNT(t.GenreId) as 'Number of Tracks'
FROM Genre g
JOIN Track t ON g.GenreId = t.GenreId
GROUP BY g.Name
ORDER BY COUNT(t.GenreId) DESC
LIMIT 5;
 
  /*
What is the average length of tracks in each genre?
 */
 SELECT g.Name, AVG(t.Milliseconds) as 'Average Length (ms)'
FROM Genre g
JOIN Track t ON g.GenreId = t.GenreId
GROUP BY g.Name;

  /*
What are the names and total quantities of tracks 
that have been purchased at least 10 times?
 */
 SELECT t.Name, SUM(il.Quantity) as 'Total Quantity'
FROM Track t
JOIN InvoiceLine il ON t.TrackId = il.TrackId
GROUP BY t.Name
HAVING SUM(il.Quantity) >= 10;

  /*
How many tracks belong to each genre?
  */
 SELECT Genre.Name, COUNT(Track.TrackId) as 'Number of Tracks'
FROM Track
JOIN Genre ON Genre.GenreId = Track.GenreId
GROUP BY Genre.Name;

  /*
What is the total number of tracks sold for each customer?
 */
 SELECT Customer.FirstName, Customer.LastName, SUM(InvoiceLine.Quantity) as 'Total Tracks Sold'
FROM InvoiceLine
JOIN Invoice ON Invoice.InvoiceId = InvoiceLine.InvoiceId
JOIN Customer ON Customer.CustomerId = Invoice.CustomerId
GROUP BY Customer.CustomerId;

   /*
What is the total amount of money each employee has brought in through invoices?
 */
 SELECT Employee.FirstName, Employee.LastName, SUM(Invoice.Total) as 'Total Sales'
FROM Invoice
JOIN Customer ON Customer.CustomerId = Invoice.CustomerId
JOIN Employee ON Employee.EmployeeId = Customer.SupportRepId
GROUP BY Employee.EmployeeId;

   /*
How many albums were released by each artist in the database?
 */
 SELECT a.Name, COUNT(b.AlbumId) as 'Number of Albums'
FROM Artist a
JOIN Album b
ON a.ArtistId = b.ArtistId
GROUP BY a.Name

   /*
What is the total number of tracks in each playlist?
 */
 SELECT p.Name, COUNT(pt.TrackId) as 'Total Tracks'
FROM Playlist p
JOIN PlaylistTrack pt
ON p.PlaylistId = pt.PlaylistId
GROUP BY p.Name

   /*
What is the average length of tracks in each genre?
 */
 SELECT g.Name, AVG(t.Milliseconds) as 'Average Length (ms)'
FROM Genre g
JOIN Track t
ON g.GenreId = t.GenreId
GROUP BY g.Name

   /*
How many customers in each country have made a purchase?
 */
 SELECT c.Country, COUNT(i.InvoiceId) as 'Number of Customers'
FROM Customer c
JOIN Invoice i
ON c.CustomerId = i.CustomerId
GROUP BY c.Country

   /*
What is the total revenue generated by each employee?
 */
 SELECT e.FirstName, e.LastName, SUM(i.Total) as 'Total Revenue'
FROM Employee e
JOIN Customer c
ON e.EmployeeId = c.SupportRepId
JOIN Invoice i
ON c.CustomerId = i.CustomerId
GROUP BY e.FirstName, e.LastName

 
  /*
What is the average unit price of tracks in each media type?
 */
 SELECT mt.Name, AVG(t.UnitPrice) as 'Average Unit Price'
FROM MediaType mt
JOIN Track t
ON mt.MediaTypeId = t.MediaTypeId
GROUP BY mt.Name

   /*
How many tracks were purchased in each invoice?
 */
 SELECT i.InvoiceId, COUNT(il.TrackId) as 'Number of Tracks'
FROM Invoice i
JOIN InvoiceLine il
ON i.InvoiceId = il.InvoiceId
GROUP BY i.InvoiceId

   /*
What is the average purchase total for each city?
 */
 SELECT i.BillingCity, AVG(i.Total) as 'Average Purchase Total'
FROM Invoice i
GROUP BY i.BillingCity

    /*
How many tracks are on each album?
 */
 SELECT a.Title, COUNT(t.TrackId) as 'Number of Tracks'
FROM Album a
JOIN Track t
ON a.AlbumId = t.AlbumId
GROUP BY a.Title


 
    /*
develop 10 unique question with comprehensive sql code that meet this requirement

All SQL queries run without errors and produce the intended results.

Each SQL query needs to include one or more explicit join(s). The query's JOIN or JOINs should be necessary to answer the question. If a question does not require a JOIN, please change the question to be one that does.

Each SQL query needs to include one or more aggregation(s). This could be a COUNT, AVG, SUM, or other aggregation.

Use other advanced SQL functions, such as the case function.

The project includes at least 10 unique and professional SQL queries.

Please format your queries for readability, use a SQL formatting tool like
sqlformat.org
sql-format.com

the database has the following tables with columns 
Album: AlbumId, Title, ArtistId; 
Artist: ArtistId, Name; 
Customer: CustomerId, FirstName, LastName, Company, Address, City, State, Country, PostalCode, Phone, Fax, Email, SupportRepId;
Employee: EmployeeId, LastName, FirstName, Title, ReportsTo, BirthDate, HireDate, Address, City, State, Country, PostalCode, Phone, Fax, Email;
Genre: GenreId, Name; 
Invoice: InvoiceId, CustomerId, invoiceId, InvoiceDate, BillingAddress, BillingCity, BillingState, BillingCountry, BillingPostalCode, Total;
InvoiceLine: InvoiceLineId, InvoiceId, TrackId, UnitPrice, Quantity;
MediaType: MediaTypeId, Name;
Playlist:  PlaylistId, Name;
PlaylistTrack: PlaylistId, Name;
Track: TrackId, Name, AlbumId, MediaTypeId, GenreId, Composer, Milliseconds, Bytes, UnitPrice;
 */
 
---How many tracks are there in each album?
SELECT AlbumId, COUNT(TrackId) AS "Number of Tracks"
FROM Track
GROUP BY AlbumId;


---What is the average unit price for each genre?
SELECT Genre.Name, AVG(UnitPrice) AS "Average Price"
FROM Track
INNER JOIN Genre ON Track.GenreId = Genre.GenreId
GROUP BY Genre.Name;


---How many tracks were purchased by each customer?
SELECT Customer.CustomerId, COUNT(TrackId) AS "Number of Purchases"
FROM InvoiceLine
INNER JOIN Invoice ON InvoiceLine.InvoiceId = Invoice.InvoiceId
INNER JOIN Customer ON Invoice.CustomerId = Customer.CustomerId
GROUP BY Customer.CustomerId;


---What is the average number of tracks in each playlist?
SELECT Playlist.Name, AVG(COUNT(TrackId)) AS "Average Number of Tracks"
FROM PlaylistTrack
INNER JOIN Playlist ON PlaylistTrack.PlaylistId = Playlist.PlaylistId
GROUP BY Playlist.Name;


---How many customers are there in each city?
SELECT City, COUNT(CustomerId) AS "Number of Customers"
FROM Customer
GROUP BY City;


---What is the average invoice total for each employee?
SELECT Employee.FirstName, AVG(Total) AS "Average Invoice Total"
FROM Invoice
INNER JOIN Customer ON Invoice.CustomerId = Customer.CustomerId
INNER JOIN Employee ON Customer.SupportRepId = Employee.EmployeeId
GROUP BY Employee.FirstName;


SELECT c.FirstName, c.LastName
FROM Customer c
JOIN Employee e ON c.SupportRepId = e.EmployeeId
WHERE c.City = e.City


---Find the average track length (in seconds) for each genre:

SELECT AVG(t.Milliseconds/1000) AS 'Avg Track Length (s)', g.Name AS Genre
FROM Track t
JOIN Genre g ON t.GenreId = g.GenreId
GROUP BY g.Name


---Find the number of tracks in each playlist:

SELECT p.Name AS 'Playlist Name', COUNT(pt.TrackId) AS 'Number of Tracks'
FROM Playlist p
JOIN PlaylistTrack pt ON p.PlaylistId = pt.PlaylistId
GROUP BY p.Name


---Find the total number of tracks in each media type:

SELECT mt.Name AS 'Media Type', COUNT(t.TrackId) AS 'Number of Tracks'
FROM MediaType mt
JOIN Track t ON mt.MediaTypeId = t.MediaTypeId
GROUP BY mt.Name

---Find the names and addresses of all customers who have not made a purchase:

SELECT c.FirstName, c.LastName, c.Address
FROM Customer c
LEFT JOIN Invoice i ON c.CustomerId = i.CustomerId
WHERE i.InvoiceId IS NULL

---Find the most popular genre (by number of tracks):

SELECT g.Name AS 'Genre', COUNT(t.TrackId) AS 'Number of Tracks'
FROM Genre g
JOIN Track t ON g.GenreId = t.GenreId
GROUP BY g.Name
ORDER BY COUNT(t.TrackId) DESC
LIMIT 10


---Find the names and hire dates of all employees who were hired after a given employee:

SELECT e.FirstName, e.LastName, e.HireDate
FROM Employee e
JOIN Employee given ON e.ReportsTo = given.EmployeeId
WHERE e.HireDate > given.HireDate


---Find the names and email addresses of all customers who have made a purchase of more than $50:

SELECT c.FirstName, c.LastName, c.Email
FROM Customer c
JOIN Invoice i ON c.CustomerId = i.CustomerId
WHERE i.Total > 50




--------------------------------------------------------------------------------------------------------------

   /*
What is the total quantity of tracks purchased for each customer?
 */
 SELECT c.FirstName, c.LastName, SUM(il.Quantity) as 'Total Quantity'
FROM Customer c
JOIN Invoice i
ON c.CustomerId = i.CustomerId
JOIN InvoiceLine il
ON i.InvoiceId = il.InvoiceId
GROUP BY c.FirstName, c.LastName



---Find the names and countries of all customers who have purchased tracks by a given artist:

SELECT c.FirstName, c.LastName, c.Country
FROM Customer c
JOIN Invoice i ON c.CustomerId = i.CustomerId
JOIN InvoiceLine il ON i.InvoiceId = il.InvoiceId
JOIN Track t ON il.TrackId = t.TrackId
JOIN Album a ON t.AlbumId = a.AlbumId
JOIN Artist ar ON a.ArtistId = ar.ArtistId
WHERE ar.Name = 'Given Artist'


---What is the most popular media type in each state?
SELECT State, MediaType.Name, COUNT(TrackId) AS "Number of Tracks"
FROM Customer
INNER JOIN Invoice ON Customer.CustomerId = Invoice.CustomerId
INNER JOIN InvoiceLine ON Invoice.InvoiceId = InvoiceLine.InvoiceId
INNER JOIN Track ON InvoiceLine.TrackId = Track.TrackId
INNER JOIN MediaType ON Track.MediaTypeId = MediaType.MediaTypeId
GROUP BY State, MediaType.Name
ORDER BY "Number of Tracks" DESC;



---What is the most popular genre in each country?
SELECT Country, Genre.Name, COUNT(TrackId) AS "Number of Tracks"
FROM Customer
INNER JOIN Invoice ON Customer.CustomerId = Invoice.CustomerId
INNER JOIN InvoiceLine ON Invoice.InvoiceId = InvoiceLine.InvoiceId
INNER JOIN Track ON InvoiceLine.TrackId = Track.TrackId
INNER JOIN Genre ON Track.GenreId = Genre.GenreId
GROUP BY Country, Genre.Name
ORDER BY "Number of Tracks" DESC;


---What is the total revenue for each artist?
SELECT Artist.Name, SUM(UnitPrice * Quantity) AS "Total Revenue"
FROM Track
INNER JOIN Album ON Track.AlbumId = Album.AlbumId
INNER JOIN Artist ON Album.ArtistId = Artist.ArtistId
INNER JOIN InvoiceLine ON Track.TrackId = InvoiceLine.TrackId
GROUP BY Artist.Name;